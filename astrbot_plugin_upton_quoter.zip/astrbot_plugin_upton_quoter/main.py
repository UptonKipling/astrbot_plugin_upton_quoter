# -*- coding: utf-8 -*-
"""
Upton 智能引用插件 (Upton Smart Quote)
======================================
作者: UptonKipling
适用: AstrBot >= 4.16.0

核心行为:
    1. 仅在群聊中生效,私聊不引用
    2. 仅当用户当前消息是「@bot」或「引用了 bot 的消息」时,
       bot 的回复才会在消息链头部插入 Reply 引用,
       引用的目标始终是用户当前这条消息(而非用户所引用的上一条)
    3. 若用户只是普通群聊消息(没有 @bot、没引用 bot),bot 不引用
    4. 与同一用户在同一群内互动达到设定的轮数阈值后,暂时停止引用
    5. 超过重置时长未互动,自动重置轮次,引用功能再次生效

v1.1.1 关键修复:
    - 在 OneBot/QQ 场景下,当用户用「回复」功能给 bot 发消息时,
      event.message_obj.message_id 在部分 AstrBot 版本里会被填成
      「被引用消息的 ID」而不是「用户当前消息的 ID」,导致 bot 错误地
      引用了用户所引用的旧消息。
    - 现已改为: 优先使用 raw_message.message_id,并主动排除消息链
      中所有 Reply.id,智能挑选出真正的「当前消息 ID」。
    - 同时对 result.chain 头部已有的 Reply 做强制一致性检查,
      ID 不一致时强制替换。
"""

import asyncio
import time

from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star
from astrbot.api import logger

# Reply / At 组件在不同 AstrBot 版本中的导入路径可能不同,
# 优先使用 message_components,失败则回退到 api.all。
try:
    from astrbot.api.message_components import Reply, At
except ImportError:  # pragma: no cover - 兼容旧版
    from astrbot.api.all import Reply, At  # type: ignore


class UptonQuoterPlugin(Star):
    """群聊智能引用插件实现"""

    # ------------------------------------------------------------------ #
    # 初始化 / 卸载
    # ------------------------------------------------------------------ #
    def __init__(self, context: Context, config):
        super().__init__(context)
        self.config = config

        # round_data 结构:
        # {
        #   (group_id, user_id): {
        #       "count": int,           # 已累积的「用户 @bot/引用 bot」轮次
        #       "last_active": float,   # 上次活跃时间戳(秒)
        #       "last_msg_id": str,     # 上次处理的用户消息 ID,用于去重
        #   }
        # }
        self.round_data: dict = {}
        self._cleanup_task: asyncio.Task | None = None

    async def initialize(self) -> None:
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        logger.info(
            "[UptonQuoter] 群聊智能引用插件已加载 (作者: UptonKipling) v1.1.1"
        )

    async def terminate(self) -> None:
        if self._cleanup_task and not self._cleanup_task.done():
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except (asyncio.CancelledError, Exception):
                pass
        self.round_data.clear()
        logger.info("[UptonQuoter] 群聊智能引用插件已卸载")

    # ------------------------------------------------------------------ #
    # 配置读取
    # ------------------------------------------------------------------ #
    def _get_config(self) -> dict:
        try:
            threshold = int(self.config.get("round_threshold", 10))
        except (TypeError, ValueError):
            threshold = 10
        try:
            reset = int(self.config.get("reset_minutes", 30))
        except (TypeError, ValueError):
            reset = 30
        try:
            interval = int(self.config.get("cleanup_interval", 5))
        except (TypeError, ValueError):
            interval = 5
        return {
            "enabled": bool(self.config.get("enabled", True)),
            "round_threshold": max(1, threshold),
            "reset_minutes": max(1, reset),
            "cleanup_minutes": max(1, interval),
        }

    # ------------------------------------------------------------------ #
    # 后台清理
    # ------------------------------------------------------------------ #
    async def _cleanup_loop(self) -> None:
        try:
            while True:
                cfg = self._get_config()
                sleep_seconds = max(60, cfg["cleanup_minutes"] * 60)
                try:
                    await asyncio.sleep(sleep_seconds)
                except asyncio.CancelledError:
                    raise
                self._cleanup_expired()
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"[UptonQuoter] 后台清理任务异常退出: {e}")

    def _cleanup_expired(self) -> None:
        cfg = self._get_config()
        reset_seconds = cfg["reset_minutes"] * 60
        now = time.time()
        expired_keys = [
            k for k, v in self.round_data.items()
            if now - v["last_active"] > reset_seconds
        ]
        for k in expired_keys:
            del self.round_data[k]
        if expired_keys:
            logger.debug(
                f"[UptonQuoter] 已清理 {len(expired_keys)} 条过期轮次数据"
            )

    # ------------------------------------------------------------------ #
    # 判定:用户当前消息是否「指向 bot」
    # ------------------------------------------------------------------ #
    def _is_directed_at_bot(self, event: AstrMessageEvent) -> bool:
        """
        判定当前用户消息是否指向 bot。
        以下任一条件满足即视为指向 bot:
          1) 消息链中存在 At(bot) 段
          2) 消息链中存在 Reply 段,且 Reply 引用消息的发送者是 bot

        兼容多平台字段差异:At 段兼容 qq/user_id/id;Reply 段兼容
        sender_id/user_id/from_user/from。
        """
        try:
            self_id = str(event.get_self_id() or "")
        except Exception:
            return False
        if not self_id:
            return False
        try:
            messages = event.get_messages() or []
        except Exception:
            return False

        for seg in messages:
            try:
                if isinstance(seg, At):
                    for attr in ("qq", "user_id", "id"):
                        val = getattr(seg, attr, None)
                        if val is not None and str(val) == self_id:
                            return True
                elif isinstance(seg, Reply):
                    for attr in ("sender_id", "user_id", "from_user", "from"):
                        val = getattr(seg, attr, None)
                        if val is not None and str(val) == self_id:
                            return True
            except Exception:
                continue

        return False

    # ------------------------------------------------------------------ #
    # 关键:智能解析「用户当前消息的 ID」
    # ------------------------------------------------------------------ #
    def _resolve_current_message_id(self, event: AstrMessageEvent) -> str:
        """
        在 OneBot/QQ 等平台下,当用户用「回复」功能给 bot 发送消息时,
        `event.message_obj.message_id` 在部分 AstrBot 版本里会被填充为
        「被引用消息的 ID」而不是「用户当前消息的 ID」,这会导致 bot
        错误地引用用户所引用的旧消息。

        本方法通过下列策略拿到真正的「用户当前消息 ID」:
          1) 收集消息链中所有 Reply.id(用户引用的旧消息的 ID 集合)
          2) 候选来源 1:raw_message.message_id(平台原生字段,
             始终指向用户当前这条消息)
          3) 候选来源 2:event.message_obj.message_id
          4) 优先选择「不在用户引用列表」中的候选
          5) 若全部候选都命中用户引用列表,返回空(让主流程跳过),
             避免错误地引用旧消息
        """
        # 1) 收集消息链中所有 Reply.id
        quoted_ids: set = set()
        try:
            for seg in event.get_messages() or []:
                if isinstance(seg, Reply):
                    sid = getattr(seg, "id", None)
                    if sid is not None:
                        quoted_ids.add(str(sid))
        except Exception:
            pass

        # 2) 收集候选 ID(按可靠性排序)
        candidates: list = []

        # 优先:raw_message.message_id(平台原生字段,最可靠)
        try:
            raw = getattr(event.message_obj, "raw_message", None)
            if raw is not None:
                if isinstance(raw, dict):
                    mid = raw.get("message_id")
                else:
                    mid = getattr(raw, "message_id", None)
                if mid:
                    candidates.append(str(mid))
        except Exception:
            pass

        # 回退:event.message_obj.message_id
        try:
            mid = getattr(event.message_obj, "message_id", None)
            if mid:
                candidates.append(str(mid))
        except Exception:
            pass

        # 3) 优先选择「不在用户引用列表」中的候选
        for cid in candidates:
            if cid and cid not in quoted_ids:
                logger.debug(
                    f"[UptonQuoter] 解析当前消息 ID = {cid} "
                    f"(quoted_ids={quoted_ids})"
                )
                return cid

        # 4) 全部候选都命中用户引用列表 → 无法确定,放弃引用
        if candidates:
            logger.debug(
                f"[UptonQuoter] 候选 ID {candidates} 全部命中用户引用列表 "
                f"{quoted_ids},无法确定当前消息 ID,跳过本次引用"
            )
        return ""

    # ------------------------------------------------------------------ #
    # 核心钩子:消息发送前智能引用
    # ------------------------------------------------------------------ #
    @filter.on_decorating_result()
    async def on_decorating_result(self, event: AstrMessageEvent) -> None:
        try:
            cfg = self._get_config()
            if not cfg["enabled"]:
                return

            # 1) 私聊不引用
            group_id = event.get_group_id()
            if not group_id:
                return

            # 2) 必要的发送者 ID
            sender_id = event.get_sender_id()
            if not sender_id:
                return

            # 3) 用户消息必须 @bot 或引用 bot 的消息
            if not self._is_directed_at_bot(event):
                return

            # 4) 没有可发送的内容也跳过
            result = event.get_result()
            if result is None or not getattr(result, "chain", None):
                return

            # 5) 解析用户当前消息的 ID(关键修复)
            current_msg_id = self._resolve_current_message_id(event)
            if not current_msg_id:
                return

            # 6) 维护轮次数据
            now = time.time()
            reset_seconds = cfg["reset_minutes"] * 60
            key = (str(group_id), str(sender_id))

            data = self.round_data.get(key)
            if data is None:
                data = {"count": 0, "last_active": now, "last_msg_id": ""}
                self.round_data[key] = data
            else:
                if now - data["last_active"] > reset_seconds:
                    data["count"] = 0
                    data["last_msg_id"] = ""

            # 7) 同一用户消息去重
            if data["last_msg_id"] == current_msg_id:
                data["last_active"] = now
                return

            data["last_msg_id"] = current_msg_id
            data["count"] += 1
            data["last_active"] = now
            current_count = data["count"]

            # 8) 超过阈值,跳过
            if current_count > cfg["round_threshold"]:
                logger.debug(
                    f"[UptonQuoter] 群 {group_id} 用户 {sender_id} "
                    f"已达 {current_count} 轮 (阈值 {cfg['round_threshold']}),跳过引用"
                )
                return

            # 9) 处理 result.chain 头部可能已存在的 Reply
            # 某些 AstrBot 内部流程或别的插件可能会预先在 chain 头部
            # 放一个 Reply,其 id 可能就是用户引用的旧消息(导致 bug)。
            # 这里:
            #   - 若已有 Reply 且 id == 我们要插入的 → 不重复添加
            #   - 若已有 Reply 但 id 不一致 → 移除它(强制使用我们的)
            #   - 若没有 Reply → 直接添加
            try:
                first = result.chain[0] if result.chain else None
                if isinstance(first, Reply):
                    existing_id = str(getattr(first, "id", "") or "")
                    if existing_id == current_msg_id:
                        logger.debug(
                            f"[UptonQuoter] 已有正确的 Reply({current_msg_id}),不重复添加"
                        )
                        return
                    result.chain.pop(0)
                    logger.debug(
                        f"[UptonQuoter] 移除错误的 Reply({existing_id}),"
                        f"将替换为 Reply({current_msg_id})"
                    )
            except Exception as e:
                logger.warning(f"[UptonQuoter] 检查既有 Reply 时异常: {e}")

            # 10) 在消息链头部插入我们的 Reply
            try:
                reply_seg = Reply(id=current_msg_id)
                result.chain.insert(0, reply_seg)
                logger.debug(
                    f"[UptonQuoter] 群 {group_id} 用户 {sender_id} "
                    f"第 {current_count} 轮,已添加 Reply({current_msg_id})"
                )
            except Exception as e:
                logger.error(f"[UptonQuoter] 插入 Reply 失败: {e}")

        except Exception as e:
            logger.error(f"[UptonQuoter] on_decorating_result 异常: {e}")
